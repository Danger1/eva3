package com.example.evaluacion3;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MostrarActivity extends AppCompatActivity {
    private EditText edtBuscarRut;
    private Button btnBuscar;
    private TextView tvMostrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar);
        edtBuscarRut=findViewById(R.id.edt_buscar_rut);
        tvMostrar=findViewById(R.id.tv_mostrar);
        btnBuscar=findViewById(R.id.btn_buscar);
        tvMostrar=findViewById(R.id.tv_mostrar);
        btnBuscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CrearBD CrearBD=new CrearBD(MostrarActivity.this, "bd_eva3",null,1);
                SQLiteDatabase db=CrearBD.getReadableDatabase();
                String RutBuscado=edtBuscarRut.getText().toString();
                if (RutBuscado.equals(""))
                {
                    Toast.makeText(MostrarActivity.this, "Ingrese un RUT", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Cursor resultado=db.rawQuery("select * from tabla_alumno where rut='"+RutBuscado+"'",null);
                    if (resultado.moveToFirst())
                    {
                        Toast.makeText(MostrarActivity.this, "Registro encontrado", Toast.LENGTH_SHORT).show();
                        edtBuscarRut.requestFocus();
                    }
                    else
                    {
                        Toast.makeText(MostrarActivity.this, "Registro NO encontrado", Toast.LENGTH_SHORT).show();
                        edtBuscarRut.requestFocus();
                    }
                }


            }
        });
    }
}