package com.example.evaluacion3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class InsertarActivity extends AppCompatActivity {
    private EditText edtRut, edtNombre, edtNota1, edtNota2, edtNota3;
    private Button btnIngresar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insertar);
        edtRut=findViewById(R.id.edt_rut);
        edtNombre=findViewById(R.id.edt_nombre);
        edtNota1=findViewById(R.id.edt_nota1);
        edtNota2=findViewById(R.id.edt_nota2);
        edtNota3=findViewById(R.id.edt_nota3);
        btnIngresar=findViewById(R.id.btn_ingresar);
        btnIngresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try
                {
                    String rut=edtRut.getText().toString();
                    String nombre=edtNombre.getText().toString();
                    float nota1=Float.parseFloat(edtNota1.getText().toString());
                    float nota2=Float.parseFloat(edtNota2.getText().toString());
                    float nota3=Float.parseFloat(edtNota3.getText().toString());
                    CrearBD CrearDB=new CrearBD(InsertarActivity.this,"bd_eva3",null,1);
                    SQLiteDatabase db=CrearDB.getWritableDatabase();
                    ContentValues ingreso=new ContentValues();
                    ingreso.put("rut",rut);
                    ingreso.put("nombre",nombre);
                    ingreso.put("nota1",nota1);
                    ingreso.put("nota2",nota2);
                    ingreso.put("nota3",nota3);
                    long valor = db.insert("tabla_alumno",null,ingreso);
                    if (valor>0)
                    {
                        Toast.makeText(InsertarActivity.this, "Ingreso Insertado", Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        Toast.makeText(InsertarActivity.this, "Ingreso NO insertado", Toast.LENGTH_SHORT).show();
                    }
                }
                catch(NumberFormatException ex){
                    Toast.makeText(InsertarActivity.this, "Debe ingresar las notas", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}