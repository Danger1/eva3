package com.example.evaluacion3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public boolean onCreateOptionsMenu (Menu menu)
    {
        MenuInflater x=getMenuInflater();
        x.inflate(R.menu.menu_principal,menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId()){
            case R.id.menu_insertar:
                Intent i=new Intent(this, InsertarActivity.class);
                startActivity(i);
                break;
            case R.id.buscar_rut:
                Intent o=new Intent(this,MostrarActivity.class);
                startActivity(o);
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return true;
    }
}